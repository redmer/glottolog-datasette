
Glottolog 3.2 data download
===========================

Data of Glottolog 3.2 is published under the following license:
http://creativecommons.org/licenses/by/4.0/

It should be cited as

Hammarström, Harald & Bank, Sebastian & Forkel, Robert & Haspelmath, Martin. 2018.
Glottolog 3.2.
Jena: Max Planck Institute for the Science of Human History.
(Available online at http://glottolog.org, Accessed on 2018-01-25.)
